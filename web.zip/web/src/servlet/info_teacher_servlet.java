package servlet;

        import mysql.operate_user;
        import mysql.update_teacher;
        import mysql.update_user;
        import object.user;

        import javax.servlet.ServletException;
        import javax.servlet.annotation.WebServlet;
        import javax.servlet.http.HttpServlet;
        import javax.servlet.http.HttpServletRequest;
        import javax.servlet.http.HttpServletResponse;
        import javax.servlet.http.HttpSession;
        import java.io.IOException;
        import java.io.PrintWriter;
        import java.sql.SQLException;

@WebServlet("/info_teacher_servlet")
public class info_teacher_servlet extends HttpServlet {
    public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        resp.setContentType("text/html;charset=utf-8");
        PrintWriter out = resp.getWriter();
        String name=req.getParameter("name");
        String passwd=req.getParameter("newP");
        String phone=req.getParameter("phone");

        System.out.println("info_teacher_servlet: newP:"+passwd +" phone:"+phone);

        HttpSession session= req.getSession();
        user u=(user)session.getAttribute("user");
        u.setName(name);
        u.setPhone(phone);

        System.out.println("info_teacher_servlet:"+u.getId()+" "+u.getPasswd()+" "+u.getName()+" "+u.getPhone());

        update_teacher upT=new update_teacher();
        boolean aa=false,bb=false;
        try {
             bb=upT.update(u);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        if (passwd!=null){
            if(!passwd.equals("")) {
                update_user upU = new update_user();
                try {
                    u.setPasswd(passwd);
                    aa = upU.update(u);
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        if(bb||aa){
            out.println("<script type='text/javascript' >alert('修改成功!请重新登录！');</script>");
            out.println("<script>window.location='a_web_work_1/login1/login.jsp'</script>");
        }else{
            out.println("<script type='text/javascript' >alert('修改失败！发生未知错误！');</script>");
        }
    }
    public void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doGet(req,resp);
    }

}
