package servlet;
import mysql.*;
import object.course;
import object.user;

        import javax.servlet.ServletException;
        import javax.servlet.annotation.WebServlet;
        import javax.servlet.http.HttpServlet;
        import javax.servlet.http.HttpServletRequest;
        import javax.servlet.http.HttpServletResponse;
        import javax.servlet.http.HttpSession;
        import java.io.IOException;
        import java.io.PrintWriter;
        import java.sql.SQLException;
import java.util.ArrayList;

@WebServlet("/student_choose_course_servlet")
public class student_choose_course_servlet extends HttpServlet {
    public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        int cou_id=Integer.parseInt(req.getParameter("id"));
        HttpSession session= req.getSession();
        user u=(user)session.getAttribute("user");
        int stu_id=u.getId();
        student_course_add sca= new student_course_add();
        course c=new course();
        c.setId(cou_id);
        find_course fc=new find_course();
        student_get_chosen sgc=new student_get_chosen();
        boolean b=true;
        PrintWriter out = resp.getWriter();

        try {
            ArrayList<course> cs=sgc.getCourses(stu_id);
            c=fc.find(c);
            for (int i = 0; i <cs.size() ; i++) {
                course cc=cs.get(i);
                if(c.getX()==cc.getX()&&c.getY()==cc.getY()){
                    System.out.println(c.getName());
                    System.out.println(cc.getName());
                    b=false;
                    break;
                }
            }
            if (b){
                sca.add(cou_id,stu_id);
                out.println("<script>window.location='a_web_work_1/home/s_choose.jsp'</script>");
            }
            else{
                out.println("<script type='text/javascript' >alert('fail ! time conflict !');</script>");
                out.println("<script>window.location='a_web_work_1/home/s_choose.jsp'</script>");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }


    public void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doGet(req,resp);
    }

}
