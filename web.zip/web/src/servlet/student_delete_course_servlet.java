package servlet;

import mysql.course_delete;
import mysql.student_course_add;
import mysql.student_course_del;
import object.user;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

@WebServlet("/student_delete_course_servlet")
public class student_delete_course_servlet extends HttpServlet {
    public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        int cou_id=Integer.parseInt(req.getParameter("id"));
        HttpSession session= req.getSession();
        user u=(user)session.getAttribute("user");
        int stu_id=u.getId();

        student_course_del scd= new student_course_del();
        try {
            scd.del(cou_id,stu_id);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        PrintWriter out = resp.getWriter();
        out.println("<script>window.location='a_web_work_1/home/s_choose.jsp'</script>");
    }

    public void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doGet(req,resp);
    }

}
