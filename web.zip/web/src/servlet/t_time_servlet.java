
package servlet;
        import mysql.*;
        import javax.servlet.ServletException;
        import javax.servlet.annotation.WebServlet;
        import javax.servlet.http.HttpServlet;
        import javax.servlet.http.HttpServletRequest;
        import javax.servlet.http.HttpServletResponse;
        import java.io.IOException;
        import java.io.PrintWriter;
        import java.sql.SQLException;

@WebServlet("/t_time_servlet")
public class t_time_servlet extends HttpServlet {
    public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        String t1=req.getParameter("timeS");
        String t2=req.getParameter("timeE");

        String[] strs1=t1.split("-");
        String[] strs2=t2.split("-");

        judge_date  jd=new judge_date();
        boolean i=jd.judge(Integer.parseInt(strs1[0]),Integer.parseInt(strs1[1]),Integer.parseInt(strs1[2]));
        boolean j=jd.judge(Integer.parseInt(strs2[0]),Integer.parseInt(strs2[1]),Integer.parseInt(strs2[2]));
        PrintWriter out = resp.getWriter();


            if (i&&j){
               t_update_time tut=new t_update_time();
                try {
                    tut.update(t1,t2);
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
                out.println("<script type='text/javascript' >alert('success!');</script>");
                out.println("<script>window.location='a_web_work_1/home/Home_teacher.jsp'</script>");
            }
            else{
                out.println("<script type='text/javascript' >alert('incorrect time!');</script>");
                out.println("<script>window.location='a_web_work_1/home/person_info/t_time_servlet.jsp'</script>");
            }
        }

    public void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doGet(req,resp);
    }

}