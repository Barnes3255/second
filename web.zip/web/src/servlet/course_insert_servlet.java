package servlet;

import mysql.course_insert;
import mysql.operate_user;
import object.course;
import object.user;
        import javax.servlet.ServletException;
        import javax.servlet.annotation.WebServlet;
        import javax.servlet.http.HttpServlet;
        import javax.servlet.http.HttpServletRequest;
        import javax.servlet.http.HttpServletResponse;
        import javax.servlet.http.HttpSession;
        import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

@WebServlet("/course_insert_servlet")
public class course_insert_servlet extends HttpServlet {
    public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        course co=new course();
        PrintWriter out = resp.getWriter();
        HttpSession session=req.getSession();
        user u=(user)session.getAttribute("user");
        try {
            co.setId(Integer.parseInt(req.getParameter("id")));
            co.setName(req.getParameter("name"));
            co.setTeacher(u.getName());
            co.setXuefen(req.getParameter("xuefen"));
            co.setTime(req.getParameter("time"));
            co.setX(Integer.parseInt(req.getParameter("x")));
            co.setY(Integer.parseInt(req.getParameter("y")));
            course_insert cin=new course_insert();
            cin.insert(co);
        } catch (SQLException e) {
            e.printStackTrace();
            out.println("<script type='text/javascript' >alert('修改失败！格式错误！');</script>");
        }

        out.println("<script>window.location='a_web_work_1/home/t_manage.jsp'</script>");
    }
    public void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doGet(req,resp);
    }

}
