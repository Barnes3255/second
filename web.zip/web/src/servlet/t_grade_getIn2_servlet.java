package servlet;

        import mysql.get_students;
        import mysql.t_insert_grade1;
        import mysql.t_update_grade;
        import object.grade;
        import object.user;

        import javax.servlet.ServletException;
        import javax.servlet.annotation.WebServlet;
        import javax.servlet.http.HttpServlet;
        import javax.servlet.http.HttpServletRequest;
        import javax.servlet.http.HttpServletResponse;
        import javax.servlet.http.HttpSession;
        import java.io.IOException;
        import java.io.PrintWriter;
        import java.sql.SQLException;
        import java.util.ArrayList;

@WebServlet("/t_grade_getIn2_servlet")
public class t_grade_getIn2_servlet extends HttpServlet {
    public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        PrintWriter out = resp.getWriter();
        int studentId=Integer.parseInt(req.getParameter("studentId"));
        int courseId=Integer.parseInt(req.getParameter("courseId"));

        t_update_grade tug=new t_update_grade();
        try {
            tug.update(courseId,studentId);
            out.println("<script>window.location='a_web_work_1/home/t_grade_getIn.jsp'</script>");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doGet(req,resp);
    }
}
