
package servlet;

        import mysql.find_info_s;
        import mysql.find_info_t;
        import mysql.operate_user;
        import object.user;

        import javax.servlet.ServletException;
        import javax.servlet.annotation.WebServlet;
        import javax.servlet.http.HttpServlet;
        import javax.servlet.http.HttpServletRequest;
        import javax.servlet.http.HttpServletResponse;
        import javax.servlet.http.HttpSession;
        import java.io.IOException;
        import java.io.PrintWriter;
        import java.sql.SQLException;
        import java.util.Enumeration;

@WebServlet("/login_su_ser")
public class login_su_ser extends HttpServlet {
    public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        user u=(user)req.getAttribute("user");
        if (u!=null){
            HttpSession session=req.getSession();

            resp.setContentType("text/html;charset=utf-8");
            PrintWriter out = resp.getWriter();
            out.println("<script type='text/javascript' >alert('登陆成功!');</script>");
            if (u.getIdent().equals("老师")){
                find_info_t fit=new find_info_t();
                try {
                    user newU=fit.find(u);
                    session.setAttribute("user",newU);
                } catch (SQLException e) {
                    e.printStackTrace();
                }
                System.out.println("login_su_servlet:"+u.getId()+" "+u.getPasswd()+" "+u.getIdent()+" "+u.getName()+" "+u.getPhone());
                out.println("<script>window.location='a_web_work_1/home/Home_teacher.jsp'</script>");
            }else if (u.getIdent().equals("学生")){
                find_info_s fit=new find_info_s();
                try {
                    user newU=fit.find(u);
                    session.setAttribute("user",newU);
                } catch (SQLException e) {
                    e.printStackTrace();
                }
                System.out.println("login_su_servlet:"+u.getId()+" "+u.getPasswd()+" "+u.getIdent()+" "+u.getName()+" "+u.getPhone()+"\r\n"+u.getMajor()+" "+u.getNianJi()+" "+u.getCls());
                out.println("<script>window.location='a_web_work_1/home/Home_student.jsp'</script>");
            }else{
                out.println("<script type='text/javascript' >alert('账号未绑定身份!');</script>");
                out.println("<script>window.location='a_web_work_1/login1/login.jsp'</script>");
            }

            // 获取session中所有的键值
            Enumeration<?> enumeration = session.getAttributeNames();
            // 遍历enumeration
            while (enumeration.hasMoreElements()) {
                // 获取session的属性名称
                String name = enumeration.nextElement().toString();
                // 根据键值取session中的值
                Object value = session.getAttribute(name);
                // 打印结果
                System.out.println("login_su_servlet: name:" + name + ",value:" + value );
            }

        }
    }
    public void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doGet(req,resp);
    }
}
