package servlet;

import mysql.get_students;
import mysql.t_insert_grade1;
import object.grade;
import object.user;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;

@WebServlet("/t_grade_getIn_servlet")
public class t_grade_getIn_servlet extends HttpServlet {
    public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        PrintWriter out = resp.getWriter();
        int studentId=Integer.parseInt(req.getParameter("studentId"));
        int courseId=Integer.parseInt(req.getParameter("courseId"));
        int grade=Integer.parseInt(req.getParameter("grade"));
        System.out.println("t_grade_getIn_servlet:cId:"+courseId);
        System.out.println("t_grade_getIn_servlet:sId:"+studentId);
        System.out.println("t_grade_getIn_servlet:grade:"+grade);
        grade g=new grade();
        g.setV("F");
        g.setCourseId(courseId);
        g.setStudentId(studentId);
        g.setGrade(grade);
        t_insert_grade1 tig=new t_insert_grade1();
        try {
            tig.insert(g);
            System.out.println("t_grade_getIn_servlet:2");
            out.println("<script>window.location='a_web_work_1/home/t_grade_getIn.jsp'</script>");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doGet(req,resp);
    }
}
