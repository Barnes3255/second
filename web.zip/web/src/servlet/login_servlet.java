package servlet;

import mysql.operate_user;
import object.user;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/login_servlet")
public class login_servlet extends HttpServlet {
    public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        String id=req.getParameter("id");
        String passwd=req.getParameter("password");
        int int_id;
        if(id.equals("")||passwd.equals("")){
            int_id=0;
            passwd="wrong";
        }
        else{
            int_id=Integer.parseInt(id);
        }
        user u=new user(int_id,passwd);
        operate_user opU=new operate_user();
        try {
           user user= opU.login(u);
           if(user==null){
               req.getRequestDispatcher("/login_fa_ser").forward(req,resp);
            }else{
               req.setAttribute("user",user);
               req.getRequestDispatcher("/login_su_ser").forward(req,resp);
           }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doGet(req,resp);
    }

}
