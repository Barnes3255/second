package servlet;

import mysql.get_students;
import object.user;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;

@WebServlet("/t_grade_servlet")
public class t_grade_servlet extends HttpServlet {
    public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        PrintWriter out = resp.getWriter();
        int id=Integer.parseInt(req.getParameter("id"));
        ArrayList<user> us=new ArrayList<>();
        get_students gs=new get_students();
        try {
            us=gs.getStudents(id);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        for (user uuu:us){
            System.out.println("t_grade_servlet:"+uuu.getName());
        }
        HttpSession session= req.getSession();
        session.setAttribute("students",us);
        session.setAttribute("courseId",id);
        out.println("<script>window.location='a_web_work_1/home/t_grade_getIn.jsp'</script>");
    }
    public void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doGet(req,resp);
    }
}
