package mysql;

import object.user;

import java.sql.ResultSet;
import java.sql.SQLException;

public class find_info_t {
    conn_db db=new conn_db();
    public user find(user u) throws SQLException {
        String sql1="select * from teacher where teacherID='"+u.getId()+"'";
        ResultSet res=db.sta.executeQuery(sql1);
        while(res.next()){
            String name=res.getString(2);
            u.setName(name);
            String phone=res.getString(3);
            u.setPhone(phone);
        }
     return u;
    }
}
