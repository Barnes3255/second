package mysql;

import object.user;

import java.sql.ResultSet;
import java.sql.SQLException;

public class find_info_s {
    conn_db db=new conn_db();
    public user find(user u) throws SQLException {
        String sql1="select * from student_personal where studentID='"+u.getId()+"'";
        ResultSet res=db.sta.executeQuery(sql1);
        while(res.next()){
            String name=res.getString(2);
            u.setName(name);
            String major=res.getString(3);
            u.setMajor(major);
            String nianJi=res.getString(4);
            u.setNianJi(nianJi);
            String cls=res.getString(5);
            u.setCls(cls);
            String email=res.getString(6);
            u.setEmail(email);
            String phone=res.getString(7);
            u.setPhone(phone);
            String address=res.getString(8);
            u.setAddress(address);
        }
        return u;
    }
}
