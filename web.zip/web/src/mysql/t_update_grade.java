package mysql;

import java.sql.SQLException;

public class t_update_grade {
    conn_db db=new conn_db();
    public void update(int cou_id,int stu_id) throws SQLException {
        String sql ="UPDATE grades SET visiable=\"" + "T" + "\" WHERE courseId=\'"+cou_id+"\' and studentId=\'"+stu_id+"\'";
        db.sta.executeUpdate(sql);
    }
}
