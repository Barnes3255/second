package mysql;

import object.user;

import java.sql.SQLException;

public class update_user {
    conn_db db=new conn_db();
    public boolean update(user u) throws SQLException {
        try{
            db.sta.execute("UPDATE user SET code=\"" + u.getPasswd() + "\" WHERE id=" + u.getId() + ";");
        }catch (Exception e){
            e.printStackTrace();
            return false;
        }
        return true;
    }
}
