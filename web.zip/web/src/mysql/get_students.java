package mysql;

import object.course;
import object.user;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class get_students {
    conn_db db=new conn_db();
    public ArrayList<user> getStudents(int cou_id) throws SQLException {
        ArrayList<Integer> ins=new ArrayList<>();
        String sql1="select * from choosecourse where courseId=\'"+cou_id+"\'";
        ResultSet res=db.sta.executeQuery(sql1);
        while (res.next()){
            ins.add(res.getInt("studentId"));
                System.out.println("get_students:"+res.getInt("studentId"));
        }
        String sql2="select * from student_personal";
        ResultSet res2=db.sta.executeQuery(sql2);
        ArrayList<user> us=new ArrayList<>();
        while (res2.next()){
            user u=new user();
            u.setId(res2.getInt(1));
            u.setName(res2.getString(2));
            u.setMajor(res2.getString(3));
            u.setNianJi(res2.getString(4));
            u.setCls(res2.getString(5));
            u.setPhone(res2.getString(7));
            us.add(u);
        }
        ArrayList<user> us2=new ArrayList<>();
        for (int i = 0; i < us.size(); i++) {
            user u=us.get(i);
            for (int j:ins){
                if(j==u.getId()){
                    us2.add(u);
                    break;
                }
            }
        }
        return us2;
    }
}
