package mysql;

import java.sql.SQLException;

public class t_grade_delete {
    conn_db db=new conn_db();
    public void del(int cou_id,int stu_id) throws SQLException {
        String sql="delete from grades where courseId=\'"+cou_id+"\' and studentId=\'"+stu_id+"\'";
        db.sta.executeUpdate(sql);
    }
}
