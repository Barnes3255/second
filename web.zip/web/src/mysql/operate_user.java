package mysql;

import object.user;

import java.sql.ResultSet;
import java.sql.SQLException;

public class operate_user {
    conn_db db=new conn_db();
    public user login(user u) throws SQLException {
        String sql="select * from user where id='"+u.getId()+"' and code ='"+u.getPasswd()+"'";
        ResultSet res=db.sta.executeQuery(sql);
        while(res.next()){
            String ident=res.getString(3);
            u.setIdent(ident);
        }
        if(u.getIdent().equals("")){
            return null;
        }
        return u;
    }
}
