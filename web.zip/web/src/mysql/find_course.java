package mysql;

import object.course;
import object.user;

import java.sql.ResultSet;
import java.sql.SQLException;

public class find_course {
    conn_db db=new conn_db();
    public course find(course c) throws SQLException {
        String sql1="select * from course where idcourse="+c.getId();
        ResultSet res=db.sta.executeQuery(sql1);
        while(res.next()){
            c.setName(res.getString(2));
            c.setTeacher(res.getString(3));
            c.setXuefen(res.getString(4));
            c.setTime(res.getString(5));
            c.setX(res.getInt(6));
            c.setY(res.getInt(7));
        }
        return c;
    }
}
