package mysql;

import java.sql.SQLException;

public class t_update_time {
    conn_db db=new conn_db();
    public void update(String t1,String t2) throws SQLException {
        String sql1 ="UPDATE time SET timeS=\"" + t1+ "\" WHERE id=\"1\"";
        String sql2 ="UPDATE time SET timeE=\"" + t2+ "\" WHERE id=\"1\"";
        db.sta.executeUpdate(sql1);
        db.sta.executeUpdate(sql2);
    }
}
