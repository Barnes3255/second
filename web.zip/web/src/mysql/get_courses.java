package mysql;

import object.course;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class get_courses {
    conn_db db=new conn_db();
    public ArrayList<course> getCourses() throws SQLException {
        String sql="select * from course";
        ResultSet res=db.sta.executeQuery(sql);
        ArrayList<course> courses=new ArrayList<>();
        while(res.next()) {
            course co=new course();
            co.setId(res.getInt(1));
            co.setName(res.getString(2));
            co.setTeacher(res.getString(3));
            co.setXuefen(res.getString(4));
            co.setTime(res.getString(5));
            co.setX(res.getInt(6));
            co.setY(res.getInt(7));
            courses.add(co);
        }
        return courses;
    }
}
