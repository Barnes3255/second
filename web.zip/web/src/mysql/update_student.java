package mysql;

import object.user;

import java.sql.SQLException;

public class update_student {
    conn_db db=new conn_db();
    public boolean update(user u) throws SQLException {
        try{
            db.sta.execute("UPDATE student_personal SET name=\"" + u.getName() + "\" WHERE studentID=" + u.getId() + ";");
            db.sta.execute("UPDATE student_personal SET phone=\"" + u.getPhone() + "\" WHERE studentID=" + u.getId() + ";");
            db.sta.execute("UPDATE student_personal SET email=\"" + u.getEmail() + "\" WHERE studentID=" + u.getId() + ";");
            db.sta.execute("UPDATE student_personal SET address=\"" + u.getAddress() + "\" WHERE studentID=" + u.getId() + ";");
            db.sta.execute("UPDATE student_personal SET studentClass=\"" + u.getCls() + "\" WHERE studentID=" + u.getId() + ";");
            db.sta.execute("UPDATE student_personal SET studentNianJi=\"" + u.getNianJi() + "\" WHERE studentID=" + u.getId() + ";");
            db.sta.execute("UPDATE student_personal SET studentMajor=\"" + u.getMajor() + "\" WHERE studentID=" + u.getId() + ";");
        }catch (Exception e){
            e.printStackTrace();
            return false;
        }
        return true;
    }
}
