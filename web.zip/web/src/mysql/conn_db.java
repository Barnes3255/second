package mysql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class conn_db {
    static Connection con = null;
    static Statement sta = null;
    //ResultSet res = null;
    static{

        try {
            String url = "jdbc:mysql://localhost:3306/web?serverTimezone=GMT%2B8&useUnicode=true&characterEncoding=utf-8";
            String user = "root";
            String password = "pxy123456789";
            //String sql = "select * from user";

            //加载驱动
            Class.forName("com.mysql.cj.jdbc.Driver");
            //建立连接
            con = DriverManager.getConnection(url, user, password);
            //创建statement
            sta = con.createStatement();
            //执行sql给结果集(查询用Query)
            //ResultSet res = sta.executeQuery(sql);
            //输出一下信息
//            while(res.next()) {
//                int id = res.getInt(1);
//                String passwd = res.getString(2);
//                String ident = res.getString(3);
//
//                System.out.println(id + "  " + passwd + "   " + password + "   " + ident);
//            }
            System.out.println("Mysql连接成功");

        } catch (Exception e) {
            e.printStackTrace();
        } /*finally {
            try {
                res.close();
                sta.close();
                con.close();
            }catch (Exception e){
                e.printStackTrace();
            }
        }*/
    }

}

