package mysql;

import object.course;
import object.user;

import java.sql.ResultSet;
import java.sql.SQLException;

public class course_insert {
    conn_db db=new conn_db();
    public boolean insert(course c) throws SQLException {
        String sql="insert into course(idcourse,courseName,teacher,xuefen,time,x,y) " +
                "values('"+c.getId()+"','"+c.getName()+"','"+c.getTeacher()+"','"+c.getXuefen()+"','"+c.getTime()+"','"+c.getX()+"','"+c.getY()+"')";
        db.sta.executeUpdate(sql);
       return true;
    }
}
