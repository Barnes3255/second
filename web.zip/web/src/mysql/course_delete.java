package mysql;

import java.sql.SQLException;

public class course_delete {
    conn_db db=new conn_db();
    public void delete(int i) throws SQLException {
        String sql="delete from course where idcourse=\'"+i+"\'";
        db.sta.executeUpdate(sql);
    }
}
