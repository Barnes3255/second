package mysql;

import java.sql.SQLException;

public class student_course_add {
    conn_db db=new conn_db();
    public void add(int cou_id,int stu_id) throws SQLException {

        String sql="insert into choosecourse(courseId,studentId) " +
                "values('"+cou_id+"','"+stu_id+"')";
        db.sta.executeUpdate(sql);

    }
}
