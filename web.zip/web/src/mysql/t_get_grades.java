package mysql;

import object.course;
import object.grade;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class t_get_grades {
    conn_db db=new conn_db();
    public ArrayList<grade> getGrades() throws SQLException {
        String sql="select * from grades";
        ResultSet res=db.sta.executeQuery(sql);
        ArrayList<grade> grades=new ArrayList<>();
        while(res.next()) {
            grade g=new grade();
            g.setStudentId(res.getInt(1));
            g.setCourseId(res.getInt(2));
            g.setGrade(res.getInt(3));
            g.setV(res.getString(4));
            grades.add(g);
        }
        return grades;
    }
}
