package mysql;

import object.user;

import java.sql.ResultSet;
import java.sql.SQLException;

public class update_teacher {
    conn_db db=new conn_db();
    public boolean update(user u) throws SQLException {
        try{
            db.sta.execute("UPDATE teacher SET name=\"" + u.getName() + "\" WHERE teacherID=" + u.getId() + ";");
            db.sta.execute("UPDATE teacher SET phone=\"" + u.getPhone() + "\" WHERE teacherID=" + u.getId() + ";");
        }catch (Exception e){
            e.printStackTrace();
            return false;
        }
        return true;
    }
}
