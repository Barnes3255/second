package mysql;

import object.course;
import object.grade;

import java.sql.SQLException;

public class t_insert_grade1 {
    conn_db db=new conn_db();
    public boolean insert(grade g) throws SQLException {
        String sql="insert into grades(courseId,studentId,grade,visiable) " +
                "values('"+g.getCourseId()+"','"+g.getStudentId()+"','"+g.getGrade()+"','"+g.getV()+"')";
        db.sta.executeUpdate(sql);
        return true;
    }
}
