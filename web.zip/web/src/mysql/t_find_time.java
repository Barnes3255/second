package mysql;
import java.sql.ResultSet;
import java.sql.SQLException;

public class t_find_time {
    conn_db db=new conn_db();
    public String[] find() throws SQLException {
        String sql1="select * from time where id=\"1\"";
        ResultSet res=db.sta.executeQuery(sql1);
        String[] ss=new String[2];
        while(res.next()){
            String timeS=res.getString(1);
            String timeE=res.getString(2);
            ss[0]=timeS;
            ss[1]=timeE;
        }
        return ss;
    }
}
