import mysql.conn_db;
import mysql.operate_user;
import object.user;

import java.sql.SQLException;

public class test {
    public static void main(String[] args) throws SQLException {
        user u=new user(11111111,"11111111");
        user u1=new user(11111111,"11111112");
        user u2=new user(11111,"11111111");
        operate_user opU=new operate_user();
        opU.login(u);
        opU.login(u1);
        opU.login(u2);


    }
}
