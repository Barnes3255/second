document.getElementById("choose").onclick=function () {

    if(checkDate()){
        alert("开始选课");
        window.location='s_choose.jsp'
    }else{
        alert("未在规定选课时间内");
    }

}//学生选课
document.getElementById("classes").onclick=function () {
        window.location='s_classes.jsp'

}//查看课表
document.getElementById("info").onclick=function () {
    window.location='s_info.jsp'

}//个人资料
document.getElementById("grade").onclick=function () {
    window.location='s_grade.jsp'
}//成绩排名