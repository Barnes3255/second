document.getElementById("m").onclick=function () {
    window.location='t_manage.jsp'

}//管理课程
document.getElementById("s").onclick=function () {
    window.location='t_student_form.jsp'

}//学生名册
document.getElementById("i").onclick=function () {
    window.location='t_info.jsp'

}//个人资料
document.getElementById("g").onclick=function () {
    window.location='t_grade.jsp'
}//学生成绩