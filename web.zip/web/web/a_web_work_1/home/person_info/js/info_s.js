var checkPassRegular = /^\w{6,12}$/;
var errorPass = "用户密码必须由字母、数字、下划线组成，并且长度为6-12长度";
var checkEmpty = /^$/;
function checkP (str) {
    var passwd= document.getElementById("password").value;
    var newP= document.getElementById("newP").value;
    if(checkEmpty.test(newP)){
        alert("密码不变");
        return true;
    }else{
        if(passwd!=str){
            if(!checkEmpty.test(passwd)){
                alert("原始密码错误");
                return false;
            }
        }
        if(!checkPassRegular.test(newP)){
            alert(errorPass);
            var pwd = document.getElementById("newP");
            pwd.value="";
            return false;
        }
    }
    return true;
}